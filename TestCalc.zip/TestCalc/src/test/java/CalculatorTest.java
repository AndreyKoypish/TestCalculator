import org.junit.Assert;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

public class CalculatorTest {


      @Test
    public void calculate() {
          Calculator calculator = new Calculator();
          calculator.first = 55;
          calculator.second = 55;
          double actual = calculator.calculate('/');
          double expected = 1;
          assertEquals(actual, expected);
    }
}